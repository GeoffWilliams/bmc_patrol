#!/bin/bash
echo "installed" > "/opt/coolapp/status.txt"

