#!/bin/bash
echo "bmc patrol installed" > "/opt/patrol/status.txt"
