#!/bin/bash
echo "bmc patrol installed" > /bmc_patrol.txt
